"use strict";

module.exports = require('./lib/QCloudSMS.js');
