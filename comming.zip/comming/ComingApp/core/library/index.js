
module.exports = {
  queryParser: require('./query-parser'),
  resource: require('./resource')
}
