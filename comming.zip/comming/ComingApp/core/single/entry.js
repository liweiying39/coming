"use strict";

function entry () {
}

module.exports = entry;
