git checkout release
npm run build
git checkout master
echo "\nDONE >>>>>>> \033[34m now you can run 'npm run production' \033[0m"
