"use strict";

const tools = {
  dispatcherBind: {}
};

tools.dispatcherBind.pubWriteEvent = function (user_id, content) {
};

module.exports = tools;
