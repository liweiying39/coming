# Comingly

Comingly.com is an easy way to crowd-fund meetup or event on social networks such as WeChat.

