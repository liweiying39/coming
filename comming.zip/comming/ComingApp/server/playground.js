'use strict';

const db = require('../core').getService('db');

const co = require('co');
const colors = require('colors')


co(function* () {

  try {

    let user = yield db.User.findById(2);
    console.log(user.generateToken());


  } catch (err) {
    console.log(err);
  }

});
