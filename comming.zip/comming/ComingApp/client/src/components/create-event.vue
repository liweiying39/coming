<template>
  <router-view></router-view>
</template>

<script>
  export default{
    data(){
      return {
        test: 'test'
      }
    },
    components: {},
  }
</script>
