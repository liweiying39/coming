'use strict';

import en from './en.js';
import zh from './zh_CN.js';

module.exports = {
  en: en,
  zh_CN: zh
};
