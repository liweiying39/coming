const t = function (a = 1) {
  console.log(a);
}

t();
